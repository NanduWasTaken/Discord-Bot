module.exports = {
  prefix: '!b',
  port: '2929',
  token: process.env.TOKEN
};